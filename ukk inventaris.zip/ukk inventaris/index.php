<?php
include 'partials/sidebar.php';
include 'config/koneksi.php';

// Hitung jumlah barang
$resultBarang = mysqli_query($koneksi, "SELECT COUNT(*) AS total_barang FROM barang");
$dataBarang = mysqli_fetch_assoc($resultBarang);
$jumlahBarang = $dataBarang['total_barang'];

// Hitung jumlah kategori
$resultKategori = mysqli_query($koneksi, "SELECT COUNT(*) AS total_kategori FROM kategori");
$dataKategori = mysqli_fetch_assoc($resultKategori);
$jumlahKategori = $dataKategori['total_kategori'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Inventaris Barang</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>

<div class="main-content">
    <div class="container mt-4">
        <h1 class="text-center mb-4">Sistem Manajemen Inventaris Barang</h1>
        <div class="row justify-content-center mt-5">
    <div class="col-md-4">
        <div class="card text-white bg-primary mb-3 shadow">
            <div class="card-header text-center fs-5">Total Barang</div>
            <div class="card-body text-center">
                <h3 class="card-title"><?= $jumlahBarang; ?></h3>
                <p class="card-text">Barang telah terinput</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card text-white bg-success mb-3 shadow">
            <div class="card-header text-center fs-5">Total Kategori</div>
            <div class="card-body text-center">
                <h3 class="card-title"><?= $jumlahKategori; ?></h3>
                <p class="card-text">Kategori tersedia</p>
            </div>
        </div>
    </div>
</div>

    </div>
</div>

</body>
</html>
