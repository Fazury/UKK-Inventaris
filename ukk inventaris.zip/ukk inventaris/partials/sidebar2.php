<!-- partials/sidebar.php -->
<style>
    body {
        margin: 0;
        font-family: 'Segoe UI', sans-serif;
        background-color: #4a2e2e;
        color: #f5f5f5;
    }

    .sidebar {
        position: fixed;
        top: 0;
        left: 0;
        height: 100vh;
        width: 220px;
        background-color: #1e1e1e;
        padding-top: 20px;
        z-index: 1000;
    }

    .sidebar a {
        display: block;
        color: #fff;
        padding: 15px 25px;
        text-decoration: none;
        font-weight: bold;
        transition: background-color 0.3s;
    }

    .sidebar a:hover {
        background-color: #ff4d4d;
        color: white;
    }

    .main-content {
        margin-left: 220px;
        padding: 30px;
    }
</style>

<?php include '../config/base_url.php'; ?>
<div class="sidebar">
    <a href="<?= $base_url ?>index.php">Dashboard</a>
    <a href="<?= $base_url ?>barang/index.php">Barang</a>
    <a href="<?= $base_url ?>kategori/index.php">Kategori</a>
</div>
