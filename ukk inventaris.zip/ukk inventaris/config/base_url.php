<?php
$base_url = "/XI PPLG/ukk inventaris/";
