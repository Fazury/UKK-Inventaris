<?php
include '../config/koneksi.php';
include '../partials/sidebar2.php';

$query = mysqli_query($koneksi, "SELECT * FROM kategori ORDER BY id_kategori DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Kategori</title>
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>

<div class="main-content">
    <div class="container mt-4">
        <h2 class="mb-4">Data Kategori Barang</h2>

        <div class="mb-3 d-flex gap-2 flex-wrap">
            <a href="tambah.php" class="btn btn-primary">+ Tambah Kategori</a>
            <a href="../index.php" class="btn btn-secondary">Kembali</a>
        </div>

        <div class="table-responsive">
            <table class="table table-bordered table-striped text-white bg-dark">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Nama Kategori</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($data = mysqli_fetch_assoc($query)) { ?>
                    <tr>
                        <td><?= $data['id_kategori']; ?></td>
                        <td><?= $data['nama_kategori']; ?></td>
                        <td>
                            <a href="edit.php?id=<?= $data['id_kategori']; ?>" class="btn btn-sm btn-warning">Edit</a>
                            <a href="hapus.php?id=<?= $data['id_kategori']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>
