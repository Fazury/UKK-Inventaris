<?php
include '../config/koneksi.php';

$id = isset($_GET['id']) ? $_GET['id'] : 0;

// Ambil data barang
$query = mysqli_query($koneksi, "SELECT * FROM barang WHERE id = '$id'") or die(mysqli_error($koneksi));
$data = mysqli_fetch_assoc($query);

// Ambil semua kategori untuk dropdown
$kategori = mysqli_query($koneksi, "SELECT * FROM kategori") or die(mysqli_error($koneksi));

// Proses update jika form disubmit
if (isset($_POST['submit'])) {
    $nama_barang = $_POST['nama_barang'];
    $kategori_id = $_POST['kategori_id'];
    $jumlah_stok = $_POST['jumlah_stok'];
    $harga_barang = $_POST['harga_barang'];
    $tanggal_masuk = $_POST['tanggal_masuk'];

    $update = mysqli_query($koneksi, "UPDATE barang SET 
                        nama_barang = '$nama_barang',
                        kategori_id = '$kategori_id',
                        jumlah_stok = '$jumlah_stok',
                        harga_barang = '$harga_barang',
                        tanggal_masuk = '$tanggal_masuk'
                        WHERE id = '$id'") or die(mysqli_error($koneksi));

    if ($update) {
        echo "<script>alert('Data berhasil diupdate'); window.location='index.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Barang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2>Edit Barang</h2>
    <form method="post">
        <div class="mb-3">
            <label>Nama Barang</label>
            <input type="text" name="nama_barang" class="form-control" value="<?= $data['nama_barang']; ?>" required>
        </div>
        <div class="mb-3">
            <label>Kategori</label>
            <select name="kategori_id" class="form-control" required>
                <option value="">-- Pilih Kategori --</option>
                <?php while ($row = mysqli_fetch_assoc($kategori)) { ?>
                    <option value="<?= $row['id_kategori']; ?>" <?= $data['kategori_id'] == $row['id_kategori'] ? 'selected' : ''; ?>>
                        <?= $row['nama_kategori']; ?>
                    </option>
                <?php } ?>
            </select>
        </div>
        <div class="mb-3">
            <label>Jumlah Stok</label>
            <input type="number" name="jumlah_stok" class="form-control" value="<?= $data['jumlah_stok']; ?>" required min="0">
        </div>
        <div class="mb-3">
            <label>Harga Barang</label>
            <input type="number" name="harga_barang" class="form-control" value="<?= $data['harga_barang']; ?>" required min="0">
        </div>
        <div class="mb-3">
            <label>Tanggal Masuk</label>
            <input type="date" name="tanggal_masuk" class="form-control" value="<?= $data['tanggal_masuk']; ?>" required>
        </div>
        <button type="submit" name="submit" class="btn btn-primary">Update</button>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
    </form>
</div>
</body>
</html>
