<?php
include '../config/koneksi.php';
include '../partials/sidebar2.php';

$limit = 5;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $limit;

// Filter & search
$where = "";

if (!empty($_GET['search'])) {
    $search = mysqli_real_escape_string($koneksi, $_GET['search']);
    $where .= " AND barang.nama_barang LIKE '%$search%'";
}

if (!empty($_GET['kategori'])) {
    $kategori_id = (int)$_GET['kategori'];
    $where .= " AND barang.kategori_id = $kategori_id";
}

// Total data (for pagination)
$total_data = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM barang WHERE 1=1 $where"));
$total_pages = ceil($total_data / $limit);

// Ambil data barang + kategori
$query = mysqli_query($koneksi, "SELECT barang.*, kategori.nama_kategori 
                                 FROM barang 
                                 JOIN kategori ON barang.kategori_id = kategori.id_kategori 
                                 WHERE 1=1 $where
                                 ORDER BY id DESC 
                                 LIMIT $start, $limit") or die(mysqli_error($koneksi));
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Barang</title>
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>

<div class="main-content">
    <div class="container mt-4">
        <h2 class="mb-4">Data Barang</h2>

        <div class="mb-3 d-flex gap-2 flex-wrap">
            <a href="tambah.php" class="btn btn-primary">+ Tambah Barang</a>
            <a href="../index.php" class="btn btn-secondary">Kembali</a>
            <a href="export_excel.php" class="btn btn-success">Export Excel</a>
        </div>

        <!-- Filter Form -->
        <form method="GET" class="row g-2 mb-3">
            <div class="col-md-4">
                <input type="text" name="search" class="form-control" placeholder="Cari Nama Barang"
                       value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
            </div>
            <div class="col-md-4">
                <select name="kategori" class="form-select">
                    <option value="">Semua Kategori</option>
                    <?php
                    $kategori_query = mysqli_query($koneksi, "SELECT * FROM kategori");
                    while ($kat = mysqli_fetch_assoc($kategori_query)) {
                        $selected = (isset($_GET['kategori']) && $_GET['kategori'] == $kat['id_kategori']) ? 'selected' : '';
                        echo "<option value='{$kat['id_kategori']}' $selected>{$kat['nama_kategori']}</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="col-md-4">
                <button type="submit" class="btn btn-primary">Filter</button>
                <a href="index.php" class="btn btn-secondary">Reset</a>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-bordered table-striped text-white bg-dark">
                <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Nama Barang</th>
                    <th>Kategori</th>
                    <th>Stok</th>
                    <th>Harga</th>
                    <th>Tanggal Masuk</th>
                    <th>Aksi</th>
                </tr>
                </thead>
                <tbody>
                <?php while ($data = mysqli_fetch_assoc($query)) { ?>
                    <tr>
                        <td><?= $data['id']; ?></td>
                        <td><?= $data['nama_barang']; ?></td>
                        <td><?= $data['nama_kategori']; ?></td>
                        <td><?= $data['jumlah_stok']; ?></td>
                        <td>Rp <?= number_format($data['harga_barang'], 0, ',', '.'); ?></td>
                        <td><?= $data['tanggal_masuk']; ?></td>
                        <td>
                            <a href="edit.php?id=<?= $data['id']; ?>" class="btn btn-sm btn-warning">Edit</a>
                            <a href="hapus.php?id=<?= $data['id']; ?>" class="btn btn-sm btn-danger"
                               onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                        </td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <?php
        $base_url = "index.php?";
        if (!empty($_GET['search'])) $base_url .= "search=" . urlencode($_GET['search']) . "&";
        if (!empty($_GET['kategori'])) $base_url .= "kategori=" . urlencode($_GET['kategori']) . "&";
        ?>
        <nav>
            <ul class="pagination">
                <?php if ($page > 1): ?>
                    <li class="page-item"><a class="page-link" href="<?= $base_url . "page=" . ($page - 1) ?>">« Prev</a></li>
                <?php endif; ?>
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                        <a class="page-link" href="<?= $base_url . "page=" . $i ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>
                <?php if ($page < $total_pages): ?>
                    <li class="page-item"><a class="page-link" href="<?= $base_url . "page=" . ($page + 1) ?>">Next »</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</div>

</body>
</html>
