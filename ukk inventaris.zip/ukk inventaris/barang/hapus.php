<?php
include '../config/koneksi.php';

$id = isset($_GET['id']) ? $_GET['id'] : 0;

// Validasi jika ID valid
if ($id > 0) {
    $hapus = mysqli_query($koneksi, "DELETE FROM barang WHERE id = '$id'") or die(mysqli_error($koneksi));

    if ($hapus) {
        echo "<script>alert('Data berhasil dihapus'); window.location='index.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus data'); window.location='index.php';</script>";
    }
} else {
    echo "<script>alert('ID tidak valid'); window.location='index.php';</script>";
}
?>
